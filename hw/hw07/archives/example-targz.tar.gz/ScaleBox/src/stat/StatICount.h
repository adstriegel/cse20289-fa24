#ifndef STATICOUNT_H_
#define STATICOUNT_H_

#include "StatItem.h"

class StatICount : public StatItem {
	public:
		StatICount ();
		
	private:
		int		m_nValue;	
	
	
};


#endif /*STATICOUNT_H_*/
