

/** The base class for sockets that serve as the bridge between an application
 * and the virtual network stack for the host.
 */
class VirtualSocket {
	public:
		VirtualSocket ();
		
		~VirtualSocket ();
		
		
		
		
	private:
		
};