#ifndef NETCONST_H_
#define NETCONST_H_

// Various network constants

#define ETH_MAC_LENGTH		6
#define ETH_MAC_TYPELEN		2

#define	MAX_IP_LENGTH		16

#endif /*NETCONST_H_*/
