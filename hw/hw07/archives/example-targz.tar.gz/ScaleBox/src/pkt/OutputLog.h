#ifndef OUTPUTLOG_H_
#define OUTPUTLOG_H_

#include "OutputModule.h"

/** Enable logging of packets destined for output
 */
class OutputLog : public OutputModule {
 	 	
};

#endif /*OUTPUTLOG_H_*/
