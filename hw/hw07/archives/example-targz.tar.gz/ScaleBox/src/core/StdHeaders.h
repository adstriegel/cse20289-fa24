/*
 * StdHeaders.h
 *
 *  Created on: May 31, 2013
 *      Author: striegel
 */

#ifndef STDHEADERS_H_
#define STDHEADERS_H_

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#endif /* STDHEADERS_H_ */
