#ifndef PREFETCH_H_
#define PREFETCH_H_

/** A single flow that has been accelerated via pre-fetching
 */
class PrefetchFlow {
	public:
		PrefetchFlow ();
		~PrefetchFlow ();
	
	private:	
	
};



#endif /*PREFETCH_H_*/
