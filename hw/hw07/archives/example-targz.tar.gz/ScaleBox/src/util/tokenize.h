

// Code borrowed verbatim from:
//    http://www.oopweb.com/CPP/Documents/CPPHOWTO/Volume/C++Programming-HOWTO-7.html


#ifndef _TOKENIZE_H_
#define _TOKENIZE_H_

#include <string>
using namespace std;

#include <vector>
using namespace std;

void Tokenize(const string& str, vector<string>& tokens, const string& delimiters = " ");
                      

#endif
