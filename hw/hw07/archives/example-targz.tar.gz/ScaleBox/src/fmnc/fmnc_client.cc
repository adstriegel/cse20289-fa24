/*
 * fmnc_client.cc
 *
 *  Created on: Apr 1, 2014
 *      Author: striegel
 */




