#ifndef INPUTSTEALTHCLIENT_H_
#define INPUTSTEALTHCLIENT_H_

#include "../pkt/InputModule.h"

/** The input module at place on downstream stealth clients. It keeps
 * a 
class InputStealthClient : public InputModule {
	public:
		InputStealthClient ();
		~InputStealthClient ();
		
	private:
		
};

#endif /*INPUTSTEALTHCLIENT_H_*/
