/*
 * fmnc_session.cc
 *
 *  Created on: Apr 1, 2014
 *      Author: striegel
 */




