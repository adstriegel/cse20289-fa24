

#ifndef __APPCBR_H_
#define __APPCBR_H_

/** An example application in the virtual host framework to send
 * packets across the framework through a socket at a constant
 * bit rate. 
 */
class ApplicationCBR : public ApplicationBase {
	public:
		ApplicationCBR ();
		~ApplicationCBR ();
		
		
		
	private:
		
	
};


#endif

