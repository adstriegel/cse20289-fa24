/*
 * whirlwind_signature.h
 *
 * A signature for a particular packet as computed by the Whirlwind Gateway
 *
 */

#ifndef WHIRLWIND_SIGNATURE_H_
#define WHIRLWIND_SIGNATURE_H_

class Whirlwind_Signature
{
	public:

		// Override - Compute the signature

		// Override - Compare the two signatures

	private:
		// What is the signature value?

		// Where is the actual data (which we may or may not have)?

};



#endif /* WHIRLWIND_SIGNATURE_H_ */
