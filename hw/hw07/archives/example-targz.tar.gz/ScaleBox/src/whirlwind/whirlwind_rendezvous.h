/*
 * whirlwind_rendezvous.h
 *
 * The Whirlwind Rendezvous is the rendezvous point for upstream communications from the downstream
 * UEs (User Element) to the upstream Internet. It allows for coordination of tunneled data and
 * updates to either the Internet or the Whirlwind Gateway(s).  C'est tres bien!
 *
 * The Whirlwind Rendezvous point is one or more NIC'd ScaleBox-based application.  The Whirlwind
 * Rendezvous point should be viewed as a separate application from the WhirlWind gateway.
 *
 */

#ifndef WHIRLWIND_RENDEZVOUS_H_
#define WHIRLWIND_RENDEZVOUS_H_

class Whirlwind_RendezvousPoint
{



};


#endif /* WHIRLWIND_RENDEZVOUS_H_ */
